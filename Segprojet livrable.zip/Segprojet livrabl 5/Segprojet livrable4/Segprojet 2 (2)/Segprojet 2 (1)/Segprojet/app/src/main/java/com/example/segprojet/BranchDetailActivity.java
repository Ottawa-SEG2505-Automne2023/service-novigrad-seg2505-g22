package com.example.segprojet;

import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BranchDetailActivity extends AppCompatActivity {

    private RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_branch_detail);

        ratingBar = findViewById(R.id.ratingBar);

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                // Handle the rating provided by the user (e.g., store it in the database)
                // In a real app, you would typically send this rating to a server

                // For this example, display a message to indicate the user's rating
                Toast.makeText(BranchDetailActivity.this, "You rated this branch: " + rating, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
