package com.example.segprojet;

import java.util.ArrayList;

public class Succursale {

    String name;
    String address;
    ArrayList<String> hours = new ArrayList<>();
    ArrayList<User> listOfEmployees = new ArrayList<>();
    ArrayList<Services> listOfServices = new ArrayList<>();
    ArrayList<String> providedServices = new ArrayList<>(); // Ajout du champ providedServices

    public Succursale(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public String getName() {
        return name;
    }
    public String getAddress() {
        return address;
    }

    public void addEmployee(User user) {
        listOfEmployees.add(user);
    }

    public void addService(Services service) {
        listOfServices.add(service);
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<String> getHours() {
        return hours;
    }

    public void setHours(ArrayList<String> hours) {
        this.hours = hours;
    }

    public ArrayList<User> getListOfEmployees() {
        return listOfEmployees;
    }

    public void setListOfEmployees(ArrayList<User> listOfEmployees) {
        this.listOfEmployees = listOfEmployees;
    }

    public ArrayList<Services> getListOfServices() {
        return listOfServices;
    }

    public void setListOfServices(ArrayList<Services> listOfServices) {
        this.listOfServices = listOfServices;
    }

    public ArrayList<String> getProvidedServices() {
        return providedServices;
    }

    public void setProvidedServices(ArrayList<String> providedServices) {
        this.providedServices = providedServices;
    }

    public char[] getHoursOfWork() {
        StringBuilder hoursString = new StringBuilder();
        for (String hour : hours) {
            hoursString.append(hour).append(", "); // You can format it as needed
        }

        // Convert the concatenated string to a character array
        String hoursStr = hoursString.toString();
        if (!hoursStr.isEmpty()) {
            hoursStr = hoursStr.substring(0, hoursStr.length() - 2); // Remove the trailing comma and space
        }

        return hoursStr.toCharArray();
    }

}
