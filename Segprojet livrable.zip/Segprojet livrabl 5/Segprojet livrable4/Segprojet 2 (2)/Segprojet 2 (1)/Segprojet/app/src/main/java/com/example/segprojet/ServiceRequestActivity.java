package com.example.segprojet;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.Date; // Add this import
public class ServiceRequestActivity extends AppCompatActivity {

    private EditText fullNameEditText;
    private EditText emailEditText;
    private EditText serviceDetailsEditText;
    private EditText employeeUsernameEditText; // New EditText for entering employee username
    private Button submitButton;
    private Button selectDateButton;
    private Calendar appointmentCalendar;
    private String employeeUsername; // Declare the variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_request);

        fullNameEditText = findViewById(R.id.fullNameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        serviceDetailsEditText = findViewById(R.id.serviceDetailsEditText);
        employeeUsernameEditText = findViewById(R.id.employeeUsernameEditText); // Initialize the EditText for username
        submitButton = findViewById(R.id.submitButton);
        selectDateButton = findViewById(R.id.selectDateButton);
        appointmentCalendar = Calendar.getInstance();

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user inputs
                String fullName = fullNameEditText.getText().toString().trim();
                String email = emailEditText.getText().toString().trim();
                String serviceDetails = serviceDetailsEditText.getText().toString().trim();
                String employeeUsername = employeeUsernameEditText.getText().toString().trim(); // Get employee username

                // Validate inputs
                if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(email) || TextUtils.isEmpty(serviceDetails) || TextUtils.isEmpty(employeeUsername)) {
                    // Display an error message if any field is empty
                    Toast.makeText(ServiceRequestActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } //else if (isPastDate(appointmentCalendar)) {
                    // Check if the selected appointment date is in the past
                    //Toast.makeText(ServiceRequestActivity.this, "Invalid appointment date", Toast.LENGTH_SHORT).show();
                 else {
                    // All fields are filled and appointment date is valid, proceed with the submission
                    saveServiceRequestToFirebase(fullName, email, serviceDetails, appointmentCalendar.getTime(), employeeUsername);
                    Toast.makeText(ServiceRequestActivity.this, "Service request submitted", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        appointmentCalendar.set(Calendar.YEAR, year);
                        appointmentCalendar.set(Calendar.MONTH, month);
                        appointmentCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        updateDateButtonText(appointmentCalendar);
                    }
                },
                appointmentCalendar.get(Calendar.YEAR),
                appointmentCalendar.get(Calendar.MONTH),
                appointmentCalendar.get(Calendar.DAY_OF_MONTH)
        );

        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    private boolean isPastDate(Calendar selectedDate) {
        Calendar currentDate = Calendar.getInstance();
        return selectedDate.before(currentDate);
    }

    private void updateDateButtonText(Calendar selectedDate) {
        // Implement code to update the text of your selectDateButton
    }

    private void saveServiceRequestToFirebase(String fullName, String email, String serviceDetails, Date appointmentDate, String  employeeUsername) {
        DatabaseReference serviceRequestsRef = FirebaseDatabase.getInstance().getReference("service_requests");
        String requestId = serviceRequestsRef.push().getKey();
        employeeUsername = employeeUsername; // Replace with actual employee username

        // Create a ServiceRequest object
        ServiceRequest serviceRequest = new ServiceRequest(fullName, email, serviceDetails, appointmentDate, employeeUsername);

        // Save the service request to the database
        serviceRequestsRef.child(requestId).setValue(serviceRequest);
    }
}
