package com.example.segprojet;
import java.util.Date;

public class ServiceRequest {
    private String fullName;
    private String email;
    private String serviceDetails;
    private Date appointmentDate;
    private String employeeUsername; // The assigned employee
    private String status; // "pending", "accepted", "rejected", etc.
    public ServiceRequest(String fullName, String email, String serviceDetails, Date appointmentDate,String employeeUsername) {
        this.fullName = fullName;
        this.email = email;
        this.serviceDetails = serviceDetails;
        this.appointmentDate = appointmentDate;
        this.employeeUsername = employeeUsername;
        this.status = "pending";
    }
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getServiceDetails() {
        return serviceDetails;
    }

    public void setServiceDetails(String serviceDetails) {
        this.serviceDetails = serviceDetails;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getEmployeeUsername() {
        return employeeUsername;
    }

    public void setEmployeeUsername(String employeeUsername) {
        this.employeeUsername = employeeUsername;
    }

    public String getStatus() {
        return status;
    }


    public void updateStatus(String newStatus) {
        this.status = newStatus;
    }

}
