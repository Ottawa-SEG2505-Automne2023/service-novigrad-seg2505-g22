package com.example.segprojet;


import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SearchResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchresultactivity);

        // Récupérer les résultats de la recherche de l'intent
        String searchResults = getIntent().getStringExtra("searchResults");

        // Afficher les résultats dans un TextView
        TextView resultTextView = findViewById(R.id.resultTextView);
        resultTextView.setText(searchResults);
    }
}

