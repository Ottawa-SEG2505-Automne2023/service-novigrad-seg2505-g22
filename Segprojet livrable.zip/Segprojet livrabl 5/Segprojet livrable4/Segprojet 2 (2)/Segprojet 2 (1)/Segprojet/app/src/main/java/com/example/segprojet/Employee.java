package com.example.segprojet;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Employee extends AppCompatActivity {

    private Button selectHours;
    private Button selectServices;
    private Button logOut;
    private Button selectSuccursale;
    private Button addService;
    private ListView serviceRequestsListView;
    private List<ServiceRequest> serviceRequestList;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference myRef = database.getReference("users");
    private DatabaseReference serviceRequestsRef = database.getReference("service_requests");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);

        selectHours = findViewById(R.id.selectHours);
        selectServices = findViewById(R.id.selectServices);
        logOut = findViewById(R.id.logOut2);
        selectSuccursale = findViewById(R.id.SelectSucc);
        serviceRequestsListView = findViewById(R.id.serviceRequestsListView);

        // Initialize the serviceRequestList
        serviceRequestList = new ArrayList<>();

        Button acceptButton = findViewById(R.id.acceptButton);
        Button rejectButton = findViewById(R.id.rejectButton);

        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleAcceptRejectButtonClick(true);
            }
        });

        rejectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleAcceptRejectButtonClick(false);
            }
        });

        selectSuccursale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchSelectSuccursaleActivity();
            }
        });

        selectHours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSelectHoursClick();
            }
        });

        selectServices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSelectServicesClick();
            }
        });

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logOut();
            }
        });

        Button addService = findViewById(R.id.addService);

        addService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchAddServiceActivity();
            }
        });

        // Load service requests from Firebase
        loadServiceRequests();
    }

    private void handleAcceptRejectButtonClick(boolean isAccept) {
        int selectedPosition = serviceRequestsListView.getCheckedItemPosition();
        if (selectedPosition != ListView.INVALID_POSITION) {
            ServiceRequest selectedRequest = serviceRequestList.get(selectedPosition);
            if (isAccept) {
                acceptServiceRequest(selectedRequest);
            } else {
                rejectServiceRequest(selectedRequest);
            }
        } else {
            Toast.makeText(Employee.this, "Please select a service request", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchSelectSuccursaleActivity() {
        try {
            Intent intent = new Intent(getApplicationContext(), com.example.segprojet.SelectSuccursale.class);
            intent.putExtra("Username", getUsername());
            startActivity(intent);
        } catch (Exception e) {
            handleActivityLaunchError("SelectSuccursale", e);
        }
    }

    private void handleSelectHoursClick() {
        try {
            Query checkUser = myRef.orderByChild("username").equalTo(getUsername());
            checkUser.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try {
                        String succursaleName = snapshot.child(getUsername()).child("succursaleName").getValue(String.class);
                        if (!TextUtils.isEmpty(succursaleName)) {
                            launchSelectHoursActivity(succursaleName);
                        } else {
                            Toast.makeText(Employee.this, "Select a Succursale first", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        handleDataChangeError(e);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    handleDatabaseError(error);
                }
            });
        } catch (Exception e) {
            handleOnClickError(e);
        }
    }

    private void handleSelectServicesClick() {
        try {
            Query checkUser = myRef.orderByChild("username").equalTo(getUsername());
            checkUser.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try {
                        String succursaleName = snapshot.child(getUsername()).child("succursaleName").getValue(String.class);
                        if (!TextUtils.isEmpty(succursaleName)) {
                            launchAddServiceActivity(succursaleName);
                        } else {
                            Toast.makeText(Employee.this, "Select a Succursale first", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        handleDataChangeError(e);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    handleDatabaseError(error);
                }
            });
        } catch (Exception e) {
            handleOnClickError(e);
        }
    }

    private void logOut() {
        try {
            startActivity(new Intent(getApplicationContext(), SignIn.class));
        } catch (Exception e) {
            handleActivityLaunchError("SignIn", e);
        }
    }

    private void launchAddServiceActivity() {
        try {
            Intent intent = new Intent(Employee.this, AddService.class);
            startActivity(intent);
        } catch (Exception e) {
            handleActivityLaunchError("AddService", e);
        }
    }

    private void loadServiceRequests() {
        Query serviceRequestsQuery = serviceRequestsRef.orderByChild("employeeUsername");
        serviceRequestsQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    serviceRequestList.clear();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        ServiceRequest serviceRequest = snapshot.getValue(ServiceRequest.class);
                        serviceRequestList.add(serviceRequest);
                    }
                    // serviceRequestAdapter.notifyDataSetChanged();
                } catch (Exception e) {
                    handleDataChangeError(e);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                handleDatabaseError(databaseError);
            }
        });
    }

    private void acceptServiceRequest(ServiceRequest serviceRequest) {
        serviceRequest.updateStatus("accepted");
        updateServiceRequestStatus(serviceRequest);
    }

    private void rejectServiceRequest(ServiceRequest serviceRequest) {
        serviceRequest.updateStatus("rejected");
        updateServiceRequestStatus(serviceRequest);
    }

    private void updateServiceRequestStatus(ServiceRequest serviceRequest) {
        DatabaseReference serviceRequestsRef = FirebaseDatabase.getInstance().getReference("service_requests");
        serviceRequestsRef.child(serviceRequest.getStatus()).setValue(serviceRequest);
    }

    private String getUsername() {
        Intent intent = getIntent();
        return intent.getStringExtra("username");
    }

    private void launchSelectHoursActivity(String succursaleName) {
        try {
            Intent intent = new Intent(getApplicationContext(), SelectHours.class);
            intent.putExtra("SuccursaleName", succursaleName);
            startActivity(intent);
        } catch (Exception e) {
            handleActivityLaunchError("SelectHours", e);
        }
    }

    private void launchAddServiceActivity(String succursaleName) {
        try {
            Intent intent = new Intent(getApplicationContext(), AddService.class);
            intent.putExtra("SuccursaleName", succursaleName);
            intent.putExtra("username", getUsername());
            startActivity(intent);
        } catch (Exception e) {
            handleActivityLaunchError("AddService", e);
        }
    }

    private void handleActivityLaunchError(String activityName, Exception e) {
        e.printStackTrace();
        Log.e("ERROR", "Error launching " + activityName + " activity: " + e.getMessage());
    }

    private void handleDataChangeError(Exception e) {
        e.printStackTrace();
        Log.e("ERROR", "Error processing onDataChange: " + e.getMessage());
    }

    private void handleDatabaseError(DatabaseError error) {
        Log.e("ERROR", "Database error: " + error.getMessage());
    }

    private void handleOnClickError(Exception e) {
        e.printStackTrace();
        Log.e("ERROR", "Error executing onClick: " + e.getMessage());
    }
}
