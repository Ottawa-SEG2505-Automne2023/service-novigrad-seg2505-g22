package com.example.segprojet;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class SelectSuccursale extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef;

    private EditText succursaleName;
    private EditText addressEditText;
    private Button Submit;

    // Constante pour le nom des préférences partagées
    private  final String EMPLOYEE_PREFS = "EmployeePrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_succursale);

        succursaleName = findViewById(R.id.newSuccursaleName);
        addressEditText = findViewById(R.id.addressEditText);
        Submit = findViewById(R.id.SubmitS);

        Intent intent = getIntent();
        String Username = intent.getStringExtra("Username");

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(succursaleName.getText().toString())) {
                    // Création d'une nouvelle succursale avec le nom et l'adresse
                    Succursale succ = new Succursale(succursaleName.getText().toString(), addressEditText.getText().toString());

                    // Ajout d'heures de travail
                    ArrayList<String> hoursList = new ArrayList<>();
                    // ... code pour récupérer les heures de travail depuis l'interface utilisateur ...
                    succ.setHours(hoursList);

                    // Ajout de types de services fournis
                    ArrayList<String> servicesList = new ArrayList<>();
                    // ... code pour récupérer les types de services depuis l'interface utilisateur ...
                    succ.setProvidedServices(servicesList);

                    // Sauvegarder le nom et l'adresse dans SharedPreferences
                    SharedPreferences prefs = getSharedPreferences(EMPLOYEE_PREFS, MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("employeeName", succursaleName.getText().toString());
                    editor.putString("employeeAddress", addressEditText.getText().toString());
                    editor.apply();

                    // Ajouter les informations à la base de données Firebase
                    myRef = database.getReference("succursales");
                    myRef.child(succursaleName.getText().toString()).setValue(succ);

                    // Le reste du code pour lier la succursale à l'utilisateur

                    Intent intent = new Intent(getApplicationContext(), Employee.class);
                    intent.putExtra("username", Username);
                    startActivity(intent);
                } else {
                    succursaleName.setError("Succursale Name Required");
                    return;
                }
            }
        });
    }
}