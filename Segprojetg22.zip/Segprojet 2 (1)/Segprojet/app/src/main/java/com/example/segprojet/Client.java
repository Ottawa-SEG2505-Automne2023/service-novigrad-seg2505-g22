package com.example.segprojet;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Client extends AppCompatActivity {

    private EditText searchAddress;
    private EditText hoursEditText;
    private EditText servicesEditText;
    private Button searchButton;
    private Button requestServiceButton;
    private TextView resultTextView;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference succursalesRef = database.getReference("succursales");
    private DatabaseReference serviceRequestsRef = database.getReference("service_requests");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);

        searchAddress = findViewById(R.id.searchAddress);
        hoursEditText = findViewById(R.id.hoursEditText);
        servicesEditText = findViewById(R.id.servicesEditText);
        searchButton = findViewById(R.id.searchButton);
        requestServiceButton = findViewById(R.id.requestServiceButton);
        resultTextView = findViewById(R.id.resultTextView);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addressQuery = searchAddress.getText().toString().trim();
                String hoursQuery = hoursEditText.getText().toString().trim();
                String servicesQuery = servicesEditText.getText().toString().trim();

                int filledFieldsCount = 0;
                if (!TextUtils.isEmpty(addressQuery)) {
                    filledFieldsCount++;
                }
                if (!TextUtils.isEmpty(hoursQuery)) {
                    filledFieldsCount++;
                }
                if (!TextUtils.isEmpty(servicesQuery)) {
                    filledFieldsCount++;
                }

                if (filledFieldsCount == 1) {
                    searchSuccursale(addressQuery, hoursQuery, servicesQuery);
                } else {
                    Toast.makeText(Client.this, "Veuillez remplir un seul critère de recherche", Toast.LENGTH_SHORT).show();
                }
            }
        });

        requestServiceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    submitServiceRequest();
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("ClientActivity", "Erreur lors de la soumission de la demande de service", e);
                }
            }
        });
    }

    private void searchSuccursale(String address, String hours, String services) {
        Query query = succursalesRef;

        if (!TextUtils.isEmpty(address)) {
            query = query.orderByChild("address").equalTo(address);
        }

        if (!TextUtils.isEmpty(hours)) {
            query = query.orderByChild("hoursOfWork").equalTo(hours);
        }

        if (!TextUtils.isEmpty(services)) {
            query = query.orderByChild("typeOfServices").equalTo(services);
        }

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                displaySearchResults(dataSnapshot);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Client.this, "Erreur de recherche", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void displaySearchResults(DataSnapshot dataSnapshot) {
        StringBuilder resultBuilder = new StringBuilder();

        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
            Succursale succursale = snapshot.getValue(Succursale.class);
            if (succursale != null) {
                resultBuilder.append("Nom de la succursale: ").append(succursale.getName()).append("\n");
                resultBuilder.append("Adresse: ").append(succursale.getAddress()).append("\n");
                resultBuilder.append("Heures de Travail: ").append(succursale.getHoursOfWork()).append("\n");
                resultBuilder.append("Type de Services Fournis: ").append(succursale.getListOfServices()).append("\n");
                resultBuilder.append("\n");
            }
        }

        String result = resultBuilder.toString();

        Intent intent = new Intent(Client.this, SearchResultActivity.class);
        intent.putExtra("searchResults", result);
        startActivity(intent);
    }

    private void submitServiceRequest() {
        String fullName = "Valeur réelle du client";
        String email = "john.doe@example.com";
        String serviceDetails = "Description du service demandé";

        ServiceRequest serviceRequest = new ServiceRequest(fullName, email, serviceDetails, null, null);

        saveServiceRequestToFirebase(serviceRequest);

        Toast.makeText(Client.this, "Demande de service soumise", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(Client.this, ServiceRequestActivity.class);
        // Passer des données supplémentaires à l'activité RequestActivity si nécessaire
        intent.putExtra("fullName", fullName);
        intent.putExtra("email", email);
        intent.putExtra("serviceDetails", serviceDetails);
        startActivity(intent);
    }

    private void saveServiceRequestToFirebase(ServiceRequest serviceRequest) {
        String requestId = serviceRequestsRef.push().getKey();
        serviceRequestsRef.child(requestId).setValue(serviceRequest);
    }
}
